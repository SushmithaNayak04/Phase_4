import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-contact',
  templateUrl: './customer-contact.component.html',
  styleUrls: ['./customer-contact.component.css']
})
export class CustomerContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
