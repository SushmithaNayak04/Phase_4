import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-contact',
  templateUrl: './employee-contact.component.html',
  styleUrls: ['./employee-contact.component.css']
})
export class EmployeeContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
