
// TypeScript - Strongly-Typed Scripting Language.
// TypeScript - Gives Type Support

// var value = "King";
// console.log(value);
// console.log(typeof (value));
// value = 100;

var username: String = "King Kochhar";
var age: number = 23;

console.log(username);
console.log(age);